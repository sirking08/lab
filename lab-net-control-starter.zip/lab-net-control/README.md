# Lab Net Control starter

This starter controls only traffic that passes through Squid. It does not block direct connections, VPNs, other proxies, or mobile hotspots. Bind the app to localhost and publish only through your existing HTTPS reverse proxy with administrator-only access.

Before installation: back up the current Squid configuration; verify the actual client IPs and intranet domains; inspect `http_access` order; integrate `squid/labnet-acl.conf` carefully; test one client first. The intranet allow rule must follow Squid safety denials and precede broad allows. Reconfigure affects new requests and is not a guarantee of terminating established tunnels.

`clients.example.json` is an example only. Install it as `/etc/labnet-control/clients.json` after editing to match your inventory. The app uses `/var/lib/labnet-control/state.json`; the privileged helper writes `/etc/squid/labnet/disabled.txt`.
