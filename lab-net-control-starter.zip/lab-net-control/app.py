import hmac, ipaddress, json, os, secrets, sqlite3, subprocess
from datetime import datetime, timezone
from pathlib import Path
from functools import wraps
from flask import Flask, abort, flash, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash

ETC=Path("/etc/labnet-control"); DATA=Path("/var/lib/labnet-control")
CLIENTS=ETC/"clients.json"; STATE=DATA/"state.json"; AUDIT=DATA/"audit.sqlite3"
HELPER="/usr/local/sbin/labnetctl-apply"
app=Flask(__name__)
app.secret_key=os.environ["LABNET_SECRET_KEY"]
PASSWORD_HASH=os.environ["LABNET_ADMIN_PASSWORD_HASH"]
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Strict",
                  SESSION_COOKIE_SECURE=True, MAX_CONTENT_LENGTH=16384)

def load(path, default):
    try: return json.loads(path.read_text())
    except FileNotFoundError: return default
def clients():
    out={}
    for row in load(CLIENTS, {"clients":[]})["clients"]:
        ip=str(ipaddress.ip_address(row["ip"]))
        if ip in out: raise RuntimeError("Duplicate IP in clients.json")
        out[ip]=str(row["name"])
    return out
def state():
    s=load(STATE, {"lab_enabled":True,"disabled_ips":[]})
    known=set(clients())
    s["disabled_ips"]=sorted({str(ipaddress.ip_address(x)) for x in s.get("disabled_ips",[])} & known)
    s["lab_enabled"]=bool(s.get("lab_enabled",True))
    return s
def save(s):
    DATA.mkdir(parents=True,exist_ok=True)
    tmp=STATE.with_suffix(".tmp"); tmp.write_text(json.dumps(s,indent=2)+"\n")
    os.chmod(tmp,0o640); os.replace(tmp,STATE)
def audit(action,detail):
    with sqlite3.connect(AUDIT) as db:
        db.execute("CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, at_utc TEXT, username TEXT, action TEXT, detail TEXT)")
        db.execute("INSERT INTO audit(at_utc,username,action,detail) VALUES(?,?,?,?)",
                   (datetime.now(timezone.utc).isoformat(),session.get("username","system"),action,detail))
def csrf_ok():
    return bool(request.form.get("csrf_token") and session.get("csrf_token") and
                hmac.compare_digest(request.form["csrf_token"],session["csrf_token"]))
def login_required(fn):
    @wraps(fn)
    def wrapped(*a,**kw):
        if not session.get("authenticated"): return redirect(url_for("login"))
        return fn(*a,**kw)
    return wrapped
def apply():
    subprocess.run(["/usr/bin/sudo","-n",HELPER],check=True,timeout=30,capture_output=True,text=True)
@app.after_request
def headers(r):
    r.headers["X-Content-Type-Options"]="nosniff"; r.headers["X-Frame-Options"]="DENY"
    r.headers["Referrer-Policy"]="no-referrer"; r.headers["Cache-Control"]="no-store"
    r.headers["Content-Security-Policy"]="default-src 'self'; style-src 'self' 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'"
    return r
@app.route("/login",methods=["GET","POST"])
def login():
    session.setdefault("csrf_token",secrets.token_urlsafe(32))
    if request.method=="POST":
        if not csrf_ok(): abort(400)
        if check_password_hash(PASSWORD_HASH,request.form.get("password","")):
            session.clear(); session["authenticated"]=True; session["username"]="admin"
            session["csrf_token"]=secrets.token_urlsafe(32); audit("login","Administrator login")
            return redirect(url_for("index"))
        flash("Invalid credentials.")
    return render_template("login.html",csrf=session["csrf_token"])
@app.post("/logout")
@login_required
def logout():
    if not csrf_ok(): abort(400)
    audit("logout","Administrator logout"); session.clear(); return redirect(url_for("login"))
@app.get("/")
@login_required
def index():
    c=clients(); s=state(); blocked=set(c) if not s["lab_enabled"] else set(s["disabled_ips"])
    return render_template("index.html",clients=c,blocked=blocked,lab_enabled=s["lab_enabled"],csrf=session["csrf_token"])
@app.post("/client/<ip>/toggle")
@login_required
def toggle(ip):
    if not csrf_ok(): abort(400)
    ip=str(ipaddress.ip_address(ip)); c=clients()
    if ip not in c: abort(404)
    s=state()
    if not s["lab_enabled"]: flash("Enable the whole lab before changing an individual PC."); return redirect(url_for("index"))
    d=set(s["disabled_ips"]); action="enable_client" if ip in d else "disable_client"
    d.discard(ip) if ip in d else d.add(ip); s["disabled_ips"]=sorted(d); save(s)
    try: apply()
    except Exception as e:
        flash("Squid apply failed. Check system logs; verify the active state.")
        audit("apply_failed",action+" "+ip+" "+type(e).__name__)
    else: audit(action,f"{c[ip]} ({ip})"); flash(f"{c[ip]} updated.")
    return redirect(url_for("index"))
@app.post("/lab/toggle")
@login_required
def toggle_lab():
    if not csrf_ok(): abort(400)
    s=state(); s["lab_enabled"]=not s["lab_enabled"]; save(s)
    try: apply()
    except Exception as e:
        flash("Squid apply failed. Check system logs; verify the active state.")
        audit("apply_failed","lab toggle "+type(e).__name__)
    else: audit("lab_enabled" if s["lab_enabled"] else "lab_disabled","Whole lab toggle"); flash("Whole-lab state updated.")
    return redirect(url_for("index"))
if __name__=="__main__": app.run(host="127.0.0.1",port=5001,debug=False)
